export const rpc_eth = {
	"https": "https://mainnet.infura.io/v3/",
	"wss": "ws://127.0.0.1/ws",
};
export const rpc_goerli = {
	"https": "https://goerli.infura.io/v3/0e42c582d71b4ba5a8750f688fce07da",
	"wss": 'wss://goerli.infura.io/ws/v3/0e42c582d71b4ba5a8750f688fce07da'
}
export const rpc_bsc = {
	"https": "https://bsc-dataseed1.binance.org",
	"wss": "ws://127.0.0.1:28333/ws",
};

export const my_accounts = [
	{
		"public": "0xE41AC9E7E77b8d40475370042563aa7Ef5fc387C",
		"private": "93875250e0f680dd78b9fca4097b802f1a4fa7f2ab902a1ffe8d85abaf05f8e5",
		"nonce": 0
	}
];
