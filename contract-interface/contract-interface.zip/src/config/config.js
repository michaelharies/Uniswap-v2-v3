export const rpc_eth = {
	"https": "https://mainnet.infura.io/v3/",
	"wss": "ws://127.0.0.1/ws",
};
export const rpc_goerli = {
	"https": "https://goerli.infura.io/v3/",
	"wss": 'wss://goerli.infura.io/ws/v3/'
}
export const rpc_bsc = {
	"https": "https://bsc-dataseed1.binance.org",
	"wss": "ws://127.0.0.1:28333/ws",
};

export const my_accounts = [
	{
		"public": "",
		"private": "",
		"nonce": 0
	}
];
